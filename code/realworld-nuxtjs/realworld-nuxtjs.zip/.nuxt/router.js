import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _07b56b8f = () => interopDefault(import('..\\pages\\layout' /* webpackChunkName: "" */))
const _7a463a84 = () => interopDefault(import('..\\pages\\home' /* webpackChunkName: "" */))
const _628d4338 = () => interopDefault(import('..\\pages\\login' /* webpackChunkName: "" */))
const _41fbb438 = () => interopDefault(import('..\\pages\\profile' /* webpackChunkName: "" */))
const _dafab170 = () => interopDefault(import('..\\pages\\settings' /* webpackChunkName: "" */))
const _0832dc5c = () => interopDefault(import('..\\pages\\editor' /* webpackChunkName: "" */))
const _74672d9e = () => interopDefault(import('..\\pages\\article' /* webpackChunkName: "" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/",
    component: _07b56b8f,
    children: [{
      path: "",
      component: _7a463a84,
      name: "home"
    }, {
      path: "/login",
      component: _628d4338,
      name: "login"
    }, {
      path: "/register",
      component: _628d4338,
      name: "register"
    }, {
      path: "/profile/:username",
      component: _41fbb438,
      name: "profile"
    }, {
      path: "/settings",
      component: _dafab170,
      name: "settings"
    }, {
      path: "/editor",
      component: _0832dc5c,
      name: "editor"
    }, {
      path: "/article/:slug",
      component: _74672d9e,
      name: "article"
    }]
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
